<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_Spp extends CI_Model
{
public function streamPaymentData($nipd, $sort)
{
    $this->db->where('nipd', $nipd);

    if ($sort == '-created_at') {
        $this->db->order_by('created_at', 'DESC');
    } else {
        $this->db->order_by('created_at', 'ASC');
    }

    // Eksekusi query dan streaming data
    $query = $this->db->get('transactions');

    $this->output->set_content_type('application/json');
    $this->output->set_header('Transfer-Encoding', 'chunked');
    $this->output->set_header('X-Content-Type-Options', 'nosniff');

    echo '['; // Tambahkan tanda pembuka list

    $firstRow = true;
    while ($row = $query->unbuffered_row('array')) {
        if (!$firstRow) {
            echo ','; // Tambahkan koma sebagai pemisah antar objek
        }
        echo json_encode($row);
        ob_flush();
        flush();
        $firstRow = false;
    }

    echo ']'; // Tambahkan tanda penutup list
}



public function getDataSiswa($nipd) {
    $this->db->select('*');
    $this->db->from('siswa');
    $this->db->where('nipd', $nipd);
    $query = $this->db->get();

    if ($query->num_rows() > 0) {
        $result = $query->result_array();
     
        return $result;
    } else {
        return null;
    }
}


public function getPaymentsByDateRange($nipd, $start_date, $end_date, $sort)
{
    $this->db->select('*');
    $this->db->from('transactions');
    $this->db->where('nipd', $nipd);
    $this->db->where('created_at >=', $start_date . ' 00:00:00');
    $this->db->where('created_at <=', $end_date . ' 23:59:59');
    $this->db->order_by('created_at', $sort);

    $query = $this->db->get();

    if ($query->num_rows() > 0) {
        return $query->result();
    } else {
        return null;
    }
}



 public function getPrice($instansi)
    {
        $this->db->select('*');
        $this->db->from('biaya');
        $this->db->where('instansi', $instansi);
        $query = $this->db->get();
        return $query->result_array();
    }
    

public function getPending($nipd, $status, $sort, $start_date, $end_date) {
    $this->db->select('*');
    $this->db->from('transactions');
    $this->db->where('nipd', $nipd);
    $this->db->where('status', $status);

    if ($start_date != null) {
        $this->db->where('created_at >=', $start_date);
    }

    if ($end_date != null) {
        $this->db->where('created_at <', date('Y-m-d', strtotime($end_date . ' +1 day')));
    }

    $order_by = 'ASC';
    if ($sort == '-created_at') {
        $order_by = 'DESC';
    }

    $this->db->order_by('created_at', $order_by);
    $query = $this->db->get();
    return $query->result_array();
}


public function getakademik($nipd, $thn_akademik, $sort, $start_date, $end_date) {
    $this->db->select('*');
    $this->db->from('transactions');
    $this->db->where('nipd', $nipd);
    $this->db->where('thn_akademik', $thn_akademik);

    if ($start_date != null) {
        $this->db->where('created_at >=', $start_date);
    }

    if ($end_date != null) {
        $this->db->where('created_at <', date('Y-m-d', strtotime($end_date . ' +1 day')));
    }

    $order_by = 'ASC';
    if ($sort == '-created_at') {
        $order_by = 'DESC';
    }

    $this->db->order_by('created_at', $order_by);
    $query = $this->db->get();
    return $query->result_array();
}

public function getPreviousAcademicYear($thn_akademik)
{
    // Tahun akademik sebelumnya dengan lompatan 1 tahun
    $previousYear = $this->getPreviousYear($thn_akademik, 1);

    // Periksa apakah ada data di tabel transactions dengan tahun akademik sebelumnya
    $this->db->where('thn_akademik', $previousYear);
    $this->db->from('transactions');
    $previousYearCount = $this->db->count_all_results();

    // Jika ada data, cek apakah sudah lunas atau belum
    if ($previousYearCount > 0) {
        $previousTransactions = $this->M_Spp->check($nipd, $previousYear, $instansi);
        return $previousTransactions ? $previousYear : $thn_akademik;
    }

    // Jika tidak ada data, kembalikan tahun akademik saat ini
    return $thn_akademik;
}

// Fungsi untuk mendapatkan tahun akademik sebelumnya dengan lompatan tertentu
private function getPreviousYear($thn_akademik, $lompatan)
{
    $startYear = intval(substr($thn_akademik, 0, 4));
    $previousStartYear = $startYear - $lompatan;
    $previousEndYear = $previousStartYear + 1;

    return $previousStartYear . '/' . $previousEndYear;
}



public function check($nipd, $thn_akademik, $instansi) {
    // Mengambil total nominal dengan status 2
    $this->db->select_sum('nominal');
    $this->db->where('nipd', $nipd);
    $this->db->where('thn_akademik', $thn_akademik);
    $this->db->where('status', 2);
    $query = $this->db->get('transactions');
    $result = $query->row();
    $totalNominal = $result->nominal;

    // Mengambil total biaya berdasarkan instansi
    $this->db->select('SUM(biaya) * 12 AS total_biaya', FALSE);
    $this->db->where('instansi', $instansi);
    $query = $this->db->get('jenis_pembayaran');
    $result = $query->row();
    $totalBiaya = $result->total_biaya;

    // Membandingkan total nominal dengan total biaya
    if ($totalNominal >= $totalBiaya) {
        return true; // Jika total nominal lebih besar atau sama dengan total biaya
    } else {
        return false; // Jika total nominal lebih kecil dari total biaya
    }
}

public function checkTahunAkademikAvailability($thn_akademik)
{
    $this->db->where('thn_akademik', $thn_akademik);
    $query = $this->db->get('tahun_akademik');
    return $query->num_rows() > 0;
}

public function getsumbiaya($instansi){
	$this->db->select_sum('biaya');
	$this->db->where('instansi', $instansi);
	$query = $this->db->get('jenis_pembayaran');
	$result = $query->row();
	
	return $result;
}

public function setcount(){
        $this->db->set('status', 2);
        $this->db->where('nipd', $nipd);
        $this->db->update('transactions');    
}

public function uploadcount($nipd,$thn_akademik){
        $this->db->where('nipd', $nipd);
        $this->db->where('thn_akademik', $thn_akademik);
        $this->db->where('status', 2);
        $this->db->from('transactions');
        $upload_count = $this->db->count_all_results();
        
        return $upload_count;
}

public function thn_akademik_ifchange($nipd){
        $this->db->select('tahun_akademik');
        $this->db->where('nipd', $nipd);
        $this->db->order_by('id', 'DESC');
        $this->db->limit(1);
        $query = $this->db->get('transactions');
        
        return $query;
        
}

public function countStatusDiterima($nipd)
{
    $this->db->select_sum('nominal');
    $this->db->where('nipd', $nipd);
    $this->db->where('status', 2);
    $this->db->from('transactions');
    $row = $this->db->get()->row();
    $nominal = $row ? $row->nominal : 0;

    $this->db->where('nipd', $nipd);
    $this->db->where('status', 2);
    $this->db->from('transactions');
    $count = $this->db->count_all_results();

    return ['count' => $count, 'nominal' => $nominal];
}


public function countStatusDitolak($nipd)
{
    $this->db->where('nipd', $nipd);
    $this->db->where('status', 0);
    $this->db->from('transactions');
    $count = $this->db->count_all_results();

    $this->db->select_sum('nominal');
    $this->db->where('nipd', $nipd);
    $this->db->where('status', 0);
    $this->db->from('transactions');
    $row = $this->db->get()->row();
    $nominal = $row ? $row->nominal : 0;

    return ['count' => $count, 'nominal' => $nominal];
}

public function countStatusPending($nipd)
{
    $this->db->where('nipd', $nipd);
    $this->db->where('status', 1);
    $this->db->from('transactions');
    $count = $this->db->count_all_results();

    $this->db->select_sum('nominal');
    $this->db->where('nipd', $nipd);
    $this->db->where('status', 1);
    $this->db->from('transactions');
    $row = $this->db->get()->row();
    $nominal = $row ? $row->nominal : 0;

    return ['count' => $count, 'nominal' => $nominal];
}


public function login($nipd, $password)
{
    $this->db->select('siswa.*, kelas.instansi');
    $this->db->from('siswa');
    $this->db->join('kelas', 'siswa.kelas = kelas.kelas');
    $this->db->where('siswa.nipd', $nipd);
    $query = $this->db->get();
    $user = $query->row();

    if ($user && password_verify($password, $user->password)) {
        unset($user->password);
        
        return $user;
    }

    return ['error' => 'Invalid nipd or password'];
}


public function getActiveTahunAkademik()
{
    $this->db->where('status', '1');
    $query = $this->db->get('tahun_akademik');

    if ($query->num_rows() > 0) {
        return $query->row()->thn_akademik;
    } else {
        throw new Exception('No active academic year found');
    }
}


public function isTahunAkademikAktif($tahunAkademik)
{
    $this->db->from('tahun_akademik');
    $this->db->where('thn_akademik', $tahunAkademik);
    $this->db->where('status', '1');
    return $this->db->count_all_results() > 0;
}

public function isAktif($statusSiswa)
{
    return $statusSiswa === '1';
}


public function isSiswaAktif($nipd)
{
    $query = $this->db->get_where('siswa', ['nipd' => $nipd]);
    $result = $query->row();

    return $result && $result->status === '1';
}



public function SiswaAktif($nipd)
{
    $query = $this->db->get_where('siswa', ['nipd' => $nipd]);
    $result = $query->row();

    return $result && $result->status === '1';
}


}
